//
//  EmailViewController.swift
//  trainee
//
//  Created by Anna Ovchynnykova on 11/13/19.
//  Copyright © 2019 Anna Ovchynnykova. All rights reserved.
//

import UIKit
import FirebaseUI

class EmailViewController: FUIEmailEntryViewController{

    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true///????????????
        emailTextField.delegate = self
        
        }

    @IBAction func nextBtn(_ sender: Any) {
        guard let emailText = emailTextField.text else {return}
        didChangeEmail(emailText)
        onNext(emailText)
    }
}
extension EmailViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}

