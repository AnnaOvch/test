import UIKit
import SwiftyGif
import FirebaseUI

class GifViewController: UIViewController {

    @IBOutlet weak var gifImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpGif()
        
        
       
    }
    
    func setUpGif() {
        self.gifImageView.delegate = self
        guard let spashGifUrl = R.file.splashGif() else { return }
        guard let gifData = try? Data(contentsOf: spashGifUrl) else { return }
        guard let gifImage = try? UIImage(gifData: gifData, levelOfIntegrity: 1) else { return }
        self.gifImageView.setGifImage(gifImage, manager: .defaultManager, loopCount: 1)
    }
    
//    func loadNextVC() {
//        guard let vc = R.storyboard.main.loginVC() else {return}
//        self.present(vc, animated: true, completion: nil)
//        
//    }

}

extension GifViewController: SwiftyGifDelegate {
    func gifDidStop(sender: UIImageView) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in
            guard let uSelf = self else { return }
            uSelf.configureAuthVC()
           
        }
    }
    func configureAuthVC() {
        guard let authUI = FUIAuth.defaultAuthUI() else {return}
        authUI.delegate = self
        let providers: [FUIAuthProvider] = [
            FUIEmailAuth()]
        authUI.providers = providers
        let authViewController = authUI.authViewController()
        self.present(authViewController,animated:true)
    }
}

extension GifViewController: FUIAuthDelegate {
    func authUI(_ authUI: FUIAuth, didSignInWith user: User?, error: Error?) {
        if error == nil {
            print("success")
        } else {
            print(error)
        }
    }
    
    func emailEntryViewController(forAuthUI authUI: FUIAuth) -> FUIEmailEntryViewController {
        return EmailViewController(nibName:nil,bundle: nil,authUI: authUI)
    }
    func passwordSignInViewController(forAuthUI authUI: FUIAuth, email: String) -> FUIPasswordSignInViewController {
        return PasswordSignInViewController(nibName: nil,bundle: nil,authUI: authUI,email: email)
    }
    func authPickerViewController(forAuthUI authUI: FUIAuth) -> FUIAuthPickerViewController {
        return PickerViewController(nibName: nil,bundle: nil,authUI: authUI)
    }
}
