//
//  PasswordSignInViewController.swift
//  trainee
//
//  Created by Anna Ovchynnykova on 11/13/19.
//  Copyright © 2019 Anna Ovchynnykova. All rights reserved.
//

import UIKit
import FirebaseUI
class PasswordSignInViewController: FUIPasswordSignInViewController{
    
    var mailForPassword = ""
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.delegate = self
        passwordTextField.delegate = self
        //passwordTextField.becomeFirstResponder()
        emailTextField.text = mailForPassword //////?????????????????
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        emailTextField.text = mailForPassword
        
    }
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?, authUI: FUIAuth, email: String?) {
        super.init(nibName: nil,bundle: nil,authUI: authUI,email: email)
        guard let mail = email else { return }
        mailForPassword = mail
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @IBAction func logInBtn() {
        guard let password = passwordTextField.text else {return}
        signIn(withDefaultValue: mailForPassword, andPassword: password)
    
    }
 
}

extension PasswordSignInViewController: FUIAuthDelegate{
    func authUI(_ authUI: FUIAuth, didSignInWith user: User?, error: Error?) {
        print("authUI")
        if error == nil {
            print("success")
        } else {
            print(error)
        }
    }
}

extension PasswordSignInViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case emailTextField:
            guard let text = emailTextField.text else {return false}
            mailForPassword = text
            emailTextField.resignFirstResponder()
            return true
        case passwordTextField:
            passwordTextField.resignFirstResponder()
            return true
        default:
            break
        }
        return true
    }
}
