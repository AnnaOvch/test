//
//  PickerViewController.swift
//  trainee
//
//  Created by Anna Ovchynnykova on 11/13/19.
//  Copyright © 2019 Anna Ovchynnykova. All rights reserved.
//

import UIKit
import FirebaseUI

class PickerViewController: FUIAuthPickerViewController{

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }



}
